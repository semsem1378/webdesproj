
let roller = document.querySelector("#roller");
let pics = ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "5.jpg", "7.jpg", "8.jpg", "51.jpg", "watch1.jpg", "watch2.jpg",
    "watch3.png", "1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "5.jpg", "7.jpg", "8.jpg", "51.jpg", "watch1.jpg", "watch2.jpg", "watch3.png"];
let arr = [];
let cards = [];
let a = 0;
let check = false;
let burger = document.querySelector(".burger");
let ul = document.querySelector("ul");
let toggle = true;

for (let i = 0; i < pics.length; i += 2) {

    let rollingCard = document.createElement("div");
    rollingCard.classList.add("rollingCard");
    roller.appendChild(rollingCard);

    let obj = {
        firstPic: pics[i],
        secondPic: pics[i + 1]
    }
    arr.push(obj);
    if (i > pics.length - 3) {

        CardsSettings();
        check = true;
    }
}


function CardsSettings() {

    a = 0;
    cards = [...document.querySelectorAll(".rollingCard")];
    for (let i = 0; i < cards.length; i++) {
        cards[i].style.backgroundImage = `url(pics/${arr[i].firstPic})`;
        cards[i].addEventListener("mouseenter", () => {
            cards[i].style.backgroundImage = `url(pics/${arr[i].secondPic})`;

        });
        cards[i].addEventListener("mouseleave", () => {
            cards[i].style.backgroundImage = `url(pics/${arr[i].firstPic})`;
        })
    }
    for (const card of cards) {
        card.addEventListener("click", () => {
            localStorage.setItem("card", cards.indexOf(card));
            window.open("./product.html", "_blank");
        })
    }

    checker();

}

function makeInfoRoller() {


    console.log(cards.length);
    for (let i = 0; i < cards.length; i++) {

        console.log("hi");
        5620123
        let mil = Math.floor(data[i].price / 1000000);
        let tho = Math.floor((data[i].price - (mil * 1000000)) / 1000);
        let hun = Math.floor((data[i].price - (mil * 1000000) - (tho * 1000)));
        if (hun == 0) {
            hun = "000";
        }
        let price = mil + "," + tho + "," + hun;
        let rollingCardInfo = "<div> <h4>" + data[i].name + "</h4> <span>قیمت:" + price + " تومان </span></div>";
        cards[i].innerHTML = rollingCardInfo;
    }
}


function checker() {
    if (typeof data !== 'undefined') {
        makeInfoRoller();
    }
    else {
        setTimeout(() => {
            checker();
        }, 1000);
    }
}

burger.addEventListener("click",()=>{
   if(toggle){
       ul.classList.add("clicked");
       toggle = false;
   }else{
       toggle = true;
       ul.classList.remove("clicked");
   }
})