let slides = document.getElementsByClassName("slideShowPic");
let bulletHolder = document.querySelector(".bulletHolder");
let i = 0;
let myint = "";
slides[i].style.left = "0";
setTimeout(() => {
    for (const slide of slides) {
        slide.style.transition = "0.4s";
    }
}, 1000);
myint = setInterval(slider, 2000);

function slider() {
    slides[i].style.left = "100%";
    let j = i;
    timeoutFunc(j);

    i++;
    if (i == slides.length) {
        i = 0;
    }
    slides[i].style.left = "0";
    bulletSelector();
}



for (const slide of slides) {
    let bullet = document.createElement("div");
    bulletHolder.appendChild(bullet);
    bullet.classList.add("bullet");
    bullet.style.cursor = "pointer";
}
let bullets = document.getElementsByClassName("bullet");
bullets[0].classList.add("selected");

for (const bullet of bullets) {
    bullet.addEventListener("click", () => {
      
        j = [...bullets].indexOf(bullet);
        slides[i].style.left = "100%";
        timeoutFunc(i);
        i = j;
        slides[j].style.left = "0";
        bulletSelector();
    })
}
bulletHolder.addEventListener("mouseenter", () => {
    clearInterval(myint);
})
bulletHolder.addEventListener("mouseleave", () => {
    myint = setInterval(slider, 2000);
})

function bulletSelector() {
    for (const bullet of bullets) {
        if (bullet.classList.contains("selected")); {
            bullet.classList.remove("selected");
        }
    }
    bullets[i].classList.add("selected");
}

function timeoutFunc(j) {
    setTimeout(() => {
        slides[j].style.display = "none";
        slides[j].style.left = "-100%";
    }, 2000);
    setTimeout(() => {
        slides[j].style.display = "block";
    }, 2100);
}