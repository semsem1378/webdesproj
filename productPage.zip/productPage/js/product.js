let pic = document.getElementById("productpic");
let table = document.getElementById("info");
checkData();
function checkData() {
    if (localStorage.getItem("ready") == "0") {
        productCard();
    } else {
        setTimeout(() => {
            checkData();
        }, 100);
    }
}

function productCard() {
    let index = localStorage.getItem("card");
    console.log(index);
    console.log(pic);
    console.log(data[2]);
    pic.setAttribute("src", data[index].firstPic);

  let tableInfo = "<tr><th>مشخصات</th><th>اطلاعات</th><tr>";

    for (const k in data[index]) {
        tableInfo+= "<tr><td>" + k + "</td><td>"+ data[index][k] + "</td></tr>";
    }
    table.innerHTML = tableInfo;

}