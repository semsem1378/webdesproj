let xhttp = new XMLHttpRequest();
var data;
xhttp.onreadystatechange = function () {
    if (this.status == 200 && this.readyState == 4) {
        console.log("data recieved");
        data = JSON.parse(this.response);
        localStorage.setItem("ready","0");
       

    }else{
        console.log("waiting");
        localStorage.setItem("ready","1");

    }
}
xhttp.open("GET","./js/data.json",true);
xhttp.send();

